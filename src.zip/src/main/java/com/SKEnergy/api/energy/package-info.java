/**
 * (C) 2016 Adam AKA Sword_Korn
 */

@API(apiVersion = EnergyAPI.VERSION, owner = "SKEnergy", provides = "SKEnergy|energy")
package com.SKEnergy.api.energy;

import net.minecraftforge.fml.common.API;
import com.SKEnergy.api.EnergyAPI;