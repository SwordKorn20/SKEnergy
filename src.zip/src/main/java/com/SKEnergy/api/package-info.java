/**
 * (C) 2016 Adam AKA Sword_Korn
 */

@API(apiVersion = EnergyAPI.VERSION, owner = "EnergyAPI", provides = "EnergyAPI|energy")
package com.SKEnergy.api;

import net.minecraftforge.fml.common.API;